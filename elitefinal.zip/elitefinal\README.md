# Elite Maison

موقع Elite Maison — Vite + React، عربي / إنجليزي.

## التشغيل

يتطلب [Node.js](https://nodejs.org/) 20 أو أحدث.

```bash
npm install
npm run dev
```

ثم افتح: http://127.0.0.1:5173/

المسار العربي: `/ar`  
English: `/en`

## نسخة للمعاينة بعد البناء

```bash
npm run build
npm run preview
```

يفتح المعاينة على: http://127.0.0.1:4173/

## ملاحظات

- نموذج التواصل يتحقق في المتصفح ولا يرسل إلى خادم.
- الخطوط تُحمَّل من Google Fonts في هذه النسخة.
